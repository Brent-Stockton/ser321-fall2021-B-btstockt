package example.grpcclient;

import io.grpc.stub.StreamObserver;
import service.*;

import java.util.ArrayList;
import java.util.Stack;

public class StoryImpl extends StoryGrpc.StoryImplBase {


    ArrayList<String> story = new ArrayList<>();

    public StoryImpl(){
        super();
        // copying some dad jokes
        story.add("I woke up early one morning.");
    }

    // We are reading how many jokes the clients wants and put them in a list to send back to client
    @Override
    public void read(Empty req, StreamObserver<ReadResponse> responseObserver) {

       // System.out.println("Received from client: " + req.);
        ReadResponse.Builder response = ReadResponse.newBuilder();
        String storyHolder = "";
        for (int i=0; i < story.size(); i++){
           storyHolder += story.get(i) + "\n";
        }
        response.setSentence(storyHolder);
        response.setIsSuccess(true);
        response.setError("Error Free");
        ReadResponse resp = response.build();

        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }

    // We take the joke the user wants to set and put it in our set of jokes
    @Override
    public void write(WriteRequest req, StreamObserver<WriteResponse> responseObserver) {

        System.out.println("Received from client: " + req.getNewSentence());
        story.add(req.getNewSentence());
        WriteResponse.Builder response = WriteResponse.newBuilder();
        response.setIsSuccess(true);
        WriteResponse resp = response.build();
        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }
}

