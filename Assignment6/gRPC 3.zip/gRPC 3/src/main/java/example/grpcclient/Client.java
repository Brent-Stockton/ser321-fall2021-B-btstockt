package example.grpcclient;

import io.grpc.Channel;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import service.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 * Client that requests `parrot` method from the `EchoServer`.
 */
public class Client {
  private final EchoGrpc.EchoBlockingStub blockingStub;
  private final JokeGrpc.JokeBlockingStub blockingStub2;
  private final RegistryGrpc.RegistryBlockingStub blockingStub3;
  private final CalcGrpc.CalcBlockingStub blockingStub4;
  private final StoryGrpc.StoryBlockingStub blockingStub5;
  private final SecretGrpc.SecretBlockingStub blockingStub6;

  /** Construct client for accessing server using the existing channel. */
  public Client(Channel channel, Channel regChannel) {
    // 'channel' here is a Channel, not a ManagedChannel, so it is not this code's
    // responsibility to
    // shut it down.

    // Passing Channels to code makes code easier to test and makes it easier to
    // reuse Channels.
    blockingStub = EchoGrpc.newBlockingStub(channel);
    blockingStub2 = JokeGrpc.newBlockingStub(channel);
    blockingStub3 = RegistryGrpc.newBlockingStub(regChannel);
    blockingStub4 = CalcGrpc.newBlockingStub(channel);
    blockingStub5 = StoryGrpc.newBlockingStub(channel);
    blockingStub6 = SecretGrpc.newBlockingStub(channel);
  }

  public void askServerToParrot(String message) {
    ClientRequest request = ClientRequest.newBuilder().setMessage(message).build();
    ServerResponse response;
    try {
      response = blockingStub.parrot(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e.getMessage());
      return;
    }
    System.out.println("Received from server: " + response.getMessage());
  }


  public void askForJokes(int num) {
    JokeReq request = JokeReq.newBuilder().setNumber(num).build();
    JokeRes response;

    try {
      response = blockingStub2.getJoke(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    System.out.println("Your jokes: ");
    for (String joke : response.getJokeList()) {
      System.out.println("--- " + joke);
    }
  }

  public void askForStory() {
    Empty request = Empty.newBuilder().build();
    ReadResponse response;

    try {
      response = blockingStub5.read(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    System.out.println("Your Story: ");

    System.out.println(response.getSentence());
  }

  public void askForHints(int num) {
    SecretReq request = SecretReq.newBuilder().setNumber(num).build();
    SecretRes response;

    try {
      System.out.println("Server: ");
      response = blockingStub6.getSecret(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    System.out.println("Question: ");

    for (String hint : response.getSecretList()) {
      System.out.println("--- " + hint);
    }
  }

  public void askToAdd(ArrayList nums2Calc) {
    CalcRequest request = CalcRequest.newBuilder().addAllNum(nums2Calc).build();
    CalcResponse response;

    try {
      response = blockingStub4.add(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    System.out.println("Nums Added: ");

    System.out.println(response.getSolution());
  }

  public void askToMult(ArrayList nums2Calc) {
    CalcRequest request = CalcRequest.newBuilder().addAllNum(nums2Calc).build();
    CalcResponse response;

    try {
      response = blockingStub4.multiply(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    System.out.println("Nums Multiplied: ");

    System.out.println(response.getSolution());
  }

  public void askToDiv(ArrayList nums2Calc) {
    CalcRequest request = CalcRequest.newBuilder().addAllNum(nums2Calc).build();
    CalcResponse response;

    try {
      response = blockingStub4.divide(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    System.out.println("Nums Divided: ");

    System.out.println(response.getSolution());
  }

  public void askToSub(ArrayList nums2Calc) {
    CalcRequest request = CalcRequest.newBuilder().addAllNum(nums2Calc).build();
    CalcResponse response;

    try {
      response = blockingStub4.subtract(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    System.out.println("Nums Subtracted: ");

    System.out.println(response.getSolution());
  }

  public void addToCalcArray(int index, double arrayNum) {
    CalcRequest request = CalcRequest.newBuilder().setNum(index, arrayNum).build();
    CalcResponse response;

    try {
      response = blockingStub4.add(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    System.out.println("Nums : ");

    System.out.println(response.getSolution());
  }

  public void setStorySentence(String sentence) {
    WriteRequest request = WriteRequest.newBuilder().setNewSentence(sentence).build();
    WriteResponse response;

    try {
      response = blockingStub5.write(request);
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
    if(response.getIsSuccess()) {
      System.out.println("Success...");
    }

  }

  public void setJoke(String joke) {
    JokeSetReq request = JokeSetReq.newBuilder().setJoke(joke).build();
    JokeSetRes response;

    try {
      response = blockingStub2.setJoke(request);
      System.out.println(response.getOk());
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
  }

  public void getServices() {
    GetServicesReq request = GetServicesReq.newBuilder().build();
    ServicesListRes response;
    try {
      response = blockingStub3.getServices(request);
      System.out.println(response.toString());
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
  }

  public void findServer(String name) {
    FindServerReq request = FindServerReq.newBuilder().setServiceName(name).build();
    SingleServerRes response;
    try {
      response = blockingStub3.findServer(request);
      System.out.println(response.toString());
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
  }

  public void findServers(String name) {
    FindServersReq request = FindServersReq.newBuilder().setServiceName(name).build();
    ServerListRes response;
    try {
      response = blockingStub3.findServers(request);
      System.out.println(response.toString());
    } catch (Exception e) {
      System.err.println("RPC failed: " + e);
      return;
    }
  }

  public static void main(String[] args) throws Exception {
    if (args.length != 5) {
      System.out
              .println("Expected arguments: <host(String)> <port(int)> <regHost(string)> <regPort(int)> <message(String)>");
      System.exit(1);
    }
    int port = 9099;
    int regPort = 9003;
    String host = args[0];
    String regHost = args[2];
    String message = args[4];
    try {
      port = Integer.parseInt(args[1]);
      regPort = Integer.parseInt(args[3]);
    } catch (NumberFormatException nfe) {
      System.out.println("[Port] must be an integer");
      System.exit(2);
    }

    // Create a communication channel to the server, known as a Channel. Channels
    // are thread-safe
    // and reusable. It is common to create channels at the beginning of your
    // application and reuse
    // them until the application shuts down.
    String target = host + ":" + port;
    ManagedChannel channel = ManagedChannelBuilder.forTarget(target)
            // Channels are secure by default (via SSL/TLS). For the example we disable TLS
            // to avoid
            // needing certificates.
            .usePlaintext().build();

    String regTarget = regHost + ":" + regPort;
    ManagedChannel regChannel = ManagedChannelBuilder.forTarget(regTarget).usePlaintext().build();
    try {

      // ##############################################################################
      // ## Assume we know the port here from the service node it is basically set through Gradle
      // here.
      // In your version you should first contact the registry to check which services
      // are available and what the port
      // etc is.

      /**
       * Your client should start off with
       * 1. contacting the Registry to check for the available services
       * 2. List the services in the terminal and the client can
       *    choose one (preferably through numbering)
       * 3. Based on what the client chooses
       *    the terminal should ask for input, eg. a new sentence, a sorting array or
       *    whatever the request needs
       * 4. The request should be sent to one of the
       *    available services (client should call the registry again and ask for a
       *    Server providing the chosen service) should send the request to this service and
       *    return the response in a good way to the client
       *
       * You should make sure your client does not crash in case the service node
       * crashes or went offline.
       */

      // Just doing some hard coded calls to the service node without using the
      // registry
      // create client
      EchoClient client = new EchoClient(channel, regChannel);

      // call the parrot service on the server
      client.askServerToParrot(message);
      client.findServers("services.Joke/setJoke");
      // get getJoke
      client.findServer("services.Joke/getJoke");
      client.getServices();

      // get parrot
      client.findServer("services.Echo/parrot");

      // get all setJoke
      client.findServers("services.Joke/setJoke");

      // get getJoke
      client.findServer("services.Joke/getJoke");

      // does not exist
      client.findServer("random");

      while(true) {
        // Reading data using readLine
        System.out.print("-------------------------------------------------\n");
        System.out.println("Welcome to gRPC Services. \nEnter Number of the service You would like to choose.");
        System.out.print("-------------------------------------------------\n");
        System.out.println("1. Joke Service: Service Sends the number of Jokes You request.\n2. Calculation Service:" +
                " Does simple calculations \nand" +
                " gets an arbitrary number of inputs to then add/subt/mul/divide them.\n" +
                "3. Story Service: Saves a story that clients have created \nsentence by sentence " +
                "and keeps track of the story." + "\n4. Covid-19 Self-Checker Service. Provide users with a list of CDC" +
                " questions\n and assess if you need immediate medical attention or can schedule a doctor's appointment");


        Scanner scan = new Scanner(System.in);
        int menuChoice = scan.nextInt();

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        switch (menuChoice) {
          case 1:
            System.out.print("How many Jokes would you like?");
            // ask the user for input how many jokes the user wants
            String num = reader.readLine();
            // calling the joked service from the server with num from user input
            client.askForJokes(Integer.valueOf(num));
            // adding a joke to the server
            //client.setJoke("I made a pencil with two erasers. It was pointless.");
            // showing 6 joked
            // client.askForJokes(Integer.valueOf(6));
            // get all setJoke

            break;

          case 2:
            System.out.println("How many numbers would you like to calculate?");
            // String numberOfCalcs = reader.readLine();
            int numCalcs = scan.nextInt();
            System.out.println("OK you want " + numCalcs + " calculations. Enter Number:");
            ArrayList<Double> nums2Calc = new ArrayList<>();
            for (int i = 0; i < numCalcs; i++) {
              double numArray = scan.nextDouble();
              // String number = reader.readLine();
              nums2Calc.add(numArray);
              System.out.println("Number: " + numArray);
            }
            System.out.println("Ok got all of your numbers!");
            boolean calcLoop = true;
            while (calcLoop) {
              System.out.println("-------------------------------");
              System.out.println("Please choose from the Menu:");
              System.out.println("-------------------------------");
              System.out.println("1.Add will add all given numbers.");
              System.out.println("2.Subtract will take the first number and subtract all the other numbers.");
              System.out.println("3.Multiply will multiply all given numbers.");
              System.out.println("4.Divide will use the first number and divide it by all other numbers");
              System.out.println("5. Back to Main Menu");

              int choice = scan.nextInt();

              switch (choice) {
                case 1:
                  client.askToAdd(nums2Calc);
                  break;
                case 2:
                  client.askToSub(nums2Calc);
                  break;
                case 3:
                  client.askToMult(nums2Calc);
                  break;
                case 4:
                  client.askToDiv(nums2Calc);
                  break;
                case 5:
                  calcLoop = false;
                  break;
                default:
                  System.out.println("Input error");
              }
            }


            break;
          case 3:
            System.out.println("First sentence added to get you started...");
            client.askForStory();
            boolean writeMore = true;
            while (writeMore) {
              System.out.print("Please Add a Sentence: ");
              String sentence = reader.readLine();
              client.setStorySentence(sentence);
              client.askForStory();
              boolean input = true;
              while (input) {
                System.out.println("Would you like to add more? Yes or No?");
                Scanner in = new Scanner(System.in);
                String more = in.nextLine();
                if (more.equalsIgnoreCase("no")) {
                  System.out.println("OK bye! Restarting Main Menu:");
                  writeMore = false;
                  input = false;
                } else if (more.equalsIgnoreCase("yes")) {
                  input = false;
                } else {
                  System.out.println("Please Type Yes or No...");
                  continue;
                }
              }
            }
          case 4:
            boolean menuLoop = true;
            Scanner covidScan = new Scanner(System.in);
            int answer;

            System.out.println("-------------------------------");
            System.out.println("Welcome to the Corona Virus Self-Checker.");
            System.out.println("-------------------------------");
            System.out.println("This automated service will provide you with " +
                    "a list of questions and make an assessment \nas to whether " +
                    "you need to seek immediate medical attention or " +
                    "can schedule a primary \ncare physician appointment.");
            System.out.println("-------------------------------");
            System.out.println("Please Choose from 3 available options: ");
            System.out.println("-------------------------------");
            System.out.println("1. Take Self-Checker Survey.");
            System.out.println("2. View a Number of Common Survey Questions.");
            System.out.println("3. Review All Survey Questions");

            answer = covidScan.nextInt();
            int numIndex =1;
            switch(answer){
              case 1:
                System.out.println("Are you ready for your first question? Yes/Quit");
                Scanner ss = new Scanner(System.in);
                boolean covidLoop = true;
                int score = 0;
                int limit = 0;
                while (covidLoop) {

                  String response = ss.nextLine();
                  boolean qLoop;

                  if (response.equalsIgnoreCase("yes")) {
                    score++;
                  } else if (response.equalsIgnoreCase("no")) {
                    score += 0;
                  } else if(response.equalsIgnoreCase("Quit")){
                    break;
                  } else {

                  }
                  if (score == 5) {
                    System.out.println("******************************************************");
                    System.out.println("*****YOU SHOULD SEEK IMMEDIATE MEDICAL ATTENTION.*****");
                    System.out.println("******************************************************");
                    break;
                  }
                  if(limit == 9){
                    System.out.println("**********************************************************");
                    System.out.println("You do not need immediate medical attention.\nPlease seek a consultation " +
                            "from you primary care physician.");
                    System.out.println("**********************************************************");
                    break;
                  }
                  //String hintNum = reader.readLine();
                  //client.askForHints(Integer.valueOf(hintNum));

                  client.askForHints(numIndex);

                  limit++;

                }
                break;
              case 2:
                while(true) {
                  System.out.println("Please enter the number of survey questions you would\nlike to preview: ");
                  boolean l = false;
                  String hintNum = reader.readLine();
                  if(Integer.valueOf(hintNum) <= 10) {
                    client.askForHints(Integer.valueOf(hintNum));
                    System.out.println("Enter: Continue/Quit");
                    Scanner s = new Scanner(System.in);
                    String res = s.nextLine();
                    if (res.equalsIgnoreCase("Continue")) {
                      continue;
                    } else if (res.equalsIgnoreCase("quit")) {
                      break;
                    } else {
                      System.out.println("Wrong input. Returning to main menu..");
                      break;
                    }
                  } else{
                    System.out.println("**ERROR: Enter number less than or equal to 10!**");
                  }

                }
              case 3:

                client.askForHints(Integer.valueOf(10));
                System.out.println("Enter: 'Quit' to exit");
                Scanner s = new Scanner(System.in);
                String res = s.nextLine();
                if (res.equalsIgnoreCase("Continue")) {
                  continue;
                } else if (res.equalsIgnoreCase("quit")) {
                  break;
                } else {
                  System.out.println("Wrong input. Returning to main menu...");
                  break;
                }
            }
        }

      }









      // ############### Contacting the registry just so you see how it can be done

      // Comment these last Service calls while in Activity 1 Task 1, they are not needed and wil throw issues without the Registry running
      // get thread's services



    } finally {
      // ManagedChannels use resources like threads and TCP connections. To prevent
      // leaking these
      // resources the channel should be shut down when it will no longer be used. If
      // it may be used
      // again leave it running.
      channel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
      regChannel.shutdownNow().awaitTermination(5, TimeUnit.SECONDS);
    }
  }
}
