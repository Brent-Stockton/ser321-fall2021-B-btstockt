package example.grpcclient;

import io.grpc.stub.StreamObserver;
import service.*;

import java.util.Stack;

public class CovidImpl extends SecretGrpc.SecretImplBase{

    // having a global set of jokes
    Stack<String> hint = new Stack<String>();

    public CovidImpl(){
        super();
        // copying some dad jokes
        hint.add(
                "Are you fully vaccinated against COVID-19? (You are considered fully vaccinated " +
                "2 weeks after your second dose in a two-shot series like Pfizer-BioNTech or Moderna " +
                "vaccines, or 2 weeks after a single-dose vaccine such as Johnson & Johnson’s Janssen vaccine.)");
        hint.add("Are you currently over the age 85?");
        hint.add("Are you currently having trouble breathing?.");
        hint.add("Are you having persistent pain or pressure in you chest?.");
        hint.add("Are you having Pale, gray, or blue-colored skin, lips, or nail beds, depending on skin tone?");
        hint.add("Are you currently experiencing a fever over 102 degrees Fahrenheit?");
        hint.add("Do You have new loss of taste or smell?");
        hint.add("Are you experiencing unusual fatigue?");
        hint.add("Are you currently residing in a long-term care facility");
        hint.add("Are you experiencing intense headaches or sensitivity to light?");
        hint.add("Do you have severe soreness in your throat?");
        hint.add("Are you experiencing difficulty swallowing?");
        hint.add("Have you travelled to South Africa in the last 10 days?");
    }

    // We are reading how many jokes the clients wants and put them in a list to send back to client
    @Override
    public void getSecret(SecretReq req, StreamObserver<SecretRes> responseObserver) {

        System.out.println("Received from client: " + req.getNumber() + " Send question:");
        SecretRes.Builder response = SecretRes.newBuilder();
        if(req.getNumber() > 1){
            hint.add(
                    "Are you fully vaccinated against COVID-19? (You are considered fully vaccinated " +
                            "2 weeks after your second dose in a two-shot series like Pfizer-BioNTech or Moderna " +
                            "vaccines, or 2 weeks after a single-dose vaccine such as Johnson & Johnson’s Janssen vaccine.)");
            hint.add("Are you currently over the age 85?");
            hint.add("Are you currently having trouble breathing?.");
            hint.add("Are you having persistent pain or pressure in you chest?.");
            hint.add("Are you having Pale, gray, or blue-colored skin, lips, or nail beds, depending on skin tone?");
            hint.add("Are you currently experiencing a fever over 102 degrees Fahrenheit?");
            hint.add("Do You have new loss of taste or smell?");
            hint.add("Are you experiencing unusual fatigue?");
            hint.add("Are you currently residing in a long-term care facility");
            hint.add("Are you experiencing intense headaches or sensitivity to light?");
            hint.add("Do you have severe soreness in your throat?");
            hint.add("Are you experiencing difficulty swallowing");
            hint.add("Have you travelled to South Africa in the last 10 days?");
        }

            for (int i = 0; i < req.getNumber(); i++) {
                if (!hint.empty()) {
                    System.out.println(response.addSecret(hint.pop()));

                } else {
                    response.addSecret("Questions Complete...");
                    break;
                }
            }

        SecretRes resp = response.build();
        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }






    public void setSecret(SecretSetReq req, StreamObserver<SecretSetRes> responseObserver) {

        System.out.println("Received from client: " + req.getSecret());
        hint.add(req.getSecret());
        SecretSetRes.Builder response = SecretSetRes.newBuilder();
        response.setOk(true);

        SecretSetRes resp = response.build();
        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }
}
