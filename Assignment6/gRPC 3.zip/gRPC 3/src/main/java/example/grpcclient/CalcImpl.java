package example.grpcclient;

import service.EchoGrpc;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.ServerMethodDefinition;
import io.grpc.stub.StreamObserver;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import service.*;
import java.util.Stack;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import buffers.RequestProtos.Request;
import buffers.RequestProtos.Request.RequestType;
import buffers.ResponseProtos.Response;

public class CalcImpl extends CalcGrpc.CalcImplBase{


    ArrayList<Double> nums = new ArrayList<>();
    
    public CalcImpl(){
        super();
        // copying some dad jokes

     
    }
    public void addToArray(CalcRequest req, StreamObserver<CalcResponse> responseObserver) {
        System.out.println("Received from client: add to array");
        CalcResponse.Builder response = CalcResponse.newBuilder();
        double sum = 0;
        response.setSolution(sum);
        CalcResponse resp = response.build();
        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }

    public void add(CalcRequest req, StreamObserver<CalcResponse> responseObserver) {
        System.out.println("Received from client: add");
        CalcResponse.Builder response = CalcResponse.newBuilder();
        double sum = 0;
        for (int i=0; i < req.getNumCount(); i++){
           sum += (req.getNum(i));
        }
        response.setSolution(sum);
        CalcResponse resp = response.build();
        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }

    public void subtract(CalcRequest req, StreamObserver<CalcResponse> responseObserver) {
        System.out.println("Received from client: subtract");
        CalcResponse.Builder response = CalcResponse.newBuilder();
        double sum = 0;
        double Num1 = req.getNum(0);
        for (int i=0; i < req.getNumCount(); i++){
            sum += (req.getNum(i));
        }
        double sub = Num1 - (sum-Num1);
        response.setSolution(sub);
        CalcResponse resp = response.build();
        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }

    public void multiply(CalcRequest req, StreamObserver<CalcResponse> responseObserver) {
        System.out.println("Received from client: multiply");
        CalcResponse.Builder response = CalcResponse.newBuilder();
        double sum = 1;
        for (int i=0; i < req.getNumCount(); i++){
            sum = sum * (req.getNum(i));
        }
        response.setSolution(sum);
        CalcResponse resp = response.build();
        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }
    public void divide(CalcRequest req, StreamObserver<CalcResponse> responseObserver) {
        System.out.println("Received from client: divide");
        CalcResponse.Builder response = CalcResponse.newBuilder();
        double sum = 0;
        double Num1 = req.getNum(0);
        for (int i=0; i < req.getNumCount(); i++){
            sum += (req.getNum(i));
        }
        double quotient = Num1 / (sum-Num1);

        response.setSolution(quotient);
        CalcResponse resp = response.build();
        responseObserver.onNext(resp);
        responseObserver.onCompleted();
    }
}
